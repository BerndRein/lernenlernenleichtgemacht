# Motion Design mit Claude Code – Einrichtung auf deinem Computer

Getestet am 18.10.2026 in einer Cloud-Sitzung: HyperFrames-Plugin 0.8.170, Node.js 22.22, FFmpeg 6.1.
Das Testvideo liegt in `renders/test-5s.mp4`.

## 1. Voraussetzungen prüfen

Im Terminal (Mac: „Terminal“, Windows: „PowerShell“):

```bash
node --version     # muss v22 oder höher zeigen
ffmpeg -version    # muss eine Versionsnummer zeigen
```

Fehlt etwas:

| | Mac (mit Homebrew) | Windows |
|---|---|---|
| Node.js 22+ | `brew install node` | `winget install OpenJS.NodeJS.LTS` |
| FFmpeg | `brew install ffmpeg` | `winget install Gyan.FFmpeg` |

Danach das Terminal schließen und neu öffnen, dann noch einmal prüfen.

## 2. HyperFrames-Plugin installieren (offizieller Weg für Claude Code)

```bash
claude plugin marketplace add heygen-com/hyperframes
claude plugin install hyperframes@hyperframes
```

Dann **Claude Code neu starten**. Unter `/plugin` → **Marketplaces** das Auto-Update für „hyperframes“ einschalten.
Aufrufen kannst du es mit `/hyperframes:hyperframes`, zum Beispiel:

> Mit /hyperframes: Erstelle ein 10-Sekunden-Intro mit eingeblendetem Titel.

## 3. Testvideo selbst rendern

```bash
cd hyperframes-test
npm run render      # schreibt die MP4 nach renders/
npm run dev         # Vorschau im Browser mit Live-Reload
```

## 4. Stimmen und Musik (später, optional)

**Higgsfield** (Stimmen von ElevenLabs, Musik von Sonilo, Soundeffekte von Mirelo):

```bash
npm install -g @higgsfield/cli
higgsfield auth login
```

**ElevenLabs** (eigener API-Key). Den Key nie in den Chat kopieren, sondern selbst in eine Umgebungsvariable eintragen:

- Mac: `nano ~/.zshrc` öffnen, eine Zeile `export ELEVENLABS_API_KEY="dein-key"` anhängen, speichern und das Terminal neu öffnen.
- Windows: `setx ELEVENLABS_API_KEY "dein-key"` ausführen und PowerShell neu öffnen.

Claude Code liest die Variable dann, ohne dass der Key im Gespräch auftaucht.

## 5. Sound-Bibliothek

```bash
mkdir -p ~/claude-sounds
```

Lade Soundeffekte von https://pixabay.com/sound-effects/ in diesen Ordner. Sag Claude danach:

> Benenne die Dateien in ~/claude-sounds eindeutig um, miss ihre Länge mit FFmpeg und schreib eine SOUNDS.md mit Datei, Länge und Einsatz.
